#!/bin/bash

# Add git-clone
add_task git-clone 0.9