Code of Conduct
===============

All contributions to - and interactions surrounding - this project will abide by
the [USGS Code of Scientific Conduct][1].



[1]: https://www.usgs.gov/office-of-science-quality-and-integrity/fundamental-science-practices
